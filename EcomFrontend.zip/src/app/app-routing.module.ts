import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LogInComponent } from './components/log-in/log-in.component';
import { RegisterComponent } from './components/register/register.component';
import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { HerosectionComponent } from './components/herosection/herosection.component';
import { ShopComponent } from './components/shop/shop.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { CartComponent } from './components/cart/cart.component';


const routes: Routes = [
  {path: '', component: LandingpageComponent},//later change it to login
  { path: 'login', component: RegisterComponent},
  { path: 'register', component:RegisterComponent},
  {path: 'home', component:LandingpageComponent},
  {path:'herosection', component:HerosectionComponent},
  {path: 'shop', component:ShopComponent},
  {path: 'checkout', component:CheckoutComponent},
  {path: 'cart', component:CartComponent},
  {path: 'admin', 
  loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }