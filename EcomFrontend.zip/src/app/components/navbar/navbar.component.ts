import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { CartService } from 'src/app/Services/cart.service';
import { Category } from 'src/app/Services/category.model';
import { ProductService } from 'src/app/Services/product.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit{

  category: Category[]=[];
  
  constructor(private productService:ProductService) { }

 

  ngOnInit(): void {
    this.fetchCategory();
   
  }
  fetchCategory() {
    this.productService.getCategories().subscribe((categories: Category[]) => {
      this.category = categories;
    });
  }

}
