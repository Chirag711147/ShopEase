import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/Services/cart.service';
import { Product } from '../productsection/product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  orders: Product[] = []; 
  totalAmount:number;

  constructor(private cartService:CartService,private router:Router) { }

  ngOnInit(): void {
    this.fetchCartItems();
    this.totalAmount = this.cartService.getTotalAmount();
  }

  fetchCartItems(): void {
    this.orders = this.cartService.getProductsInCart();
  }
  createPath(imgpath: string) {
    return `https://localhost:7247/${imgpath}`;
  }

  checkout():void
  {
    this.cartService.checkout();
    this.router.navigate(['/']);
  }

}
