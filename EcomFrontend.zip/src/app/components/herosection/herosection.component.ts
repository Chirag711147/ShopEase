import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-herosection',
  templateUrl: './herosection.component.html',
  styleUrls: ['./herosection.component.css']
})
export class HerosectionComponent implements OnInit {
  carouselItems = [
    {
      category: 'Summer Collection',
      title: 'Fall - Winter Collections 2030',
      description: 'A specialist label creating luxury essentials. Ethically crafted with an unwavering commitment to exceptional quality.',
      image: 'assets/img/hero/hero-1.jpg'
    },
    {
      category: 'Summer Collection',
      title: 'Fall - Winter Collections 2030',
      description: 'A specialist label creating luxury essentials. Ethically crafted with an unwavering commitment to exceptional quality.',
      image: 'assets/img/hero/hero-2.jpg'
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }
  

}
