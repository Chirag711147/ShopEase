import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bannersection',
  templateUrl: './bannersection.component.html',
  styleUrls: ['./bannersection.component.css']
})
export class BannersectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
