import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instagramsection',
  templateUrl: './instagramsection.component.html',
  styleUrls: ['./instagramsection.component.css']
})
export class InstagramsectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
