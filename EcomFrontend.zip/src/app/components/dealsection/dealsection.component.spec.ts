import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DealsectionComponent } from './dealsection.component';

describe('DealsectionComponent', () => {
  let component: DealsectionComponent;
  let fixture: ComponentFixture<DealsectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DealsectionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DealsectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
