import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealsection',
  templateUrl: './dealsection.component.html',
  styleUrls: ['./dealsection.component.css']
})
export class DealsectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
