import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OffcanvasmenuComponent } from './offcanvasmenu.component';

describe('OffcanvasmenuComponent', () => {
  let component: OffcanvasmenuComponent;
  let fixture: ComponentFixture<OffcanvasmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OffcanvasmenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OffcanvasmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
