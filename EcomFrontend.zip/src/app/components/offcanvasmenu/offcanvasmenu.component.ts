import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offcanvasmenu',
  templateUrl: './offcanvasmenu.component.html',
  styleUrls: ['./offcanvasmenu.component.css']
})
export class OffcanvasmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
