import { Component, OnInit } from '@angular/core';
import { Product } from './product.model';
import { ProductService } from 'src/app/Services/product.service';
import { CartService } from 'src/app/Services/cart.service';


@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {


  products: Product[] = [];
  backgroundImg:any;

  constructor(private productService: ProductService,private cartService: CartService) {
    

  }

  ngOnInit(): void {
    this.fetchProducts();
  }

  fetchProducts() {
    this.productService.getProducts().subscribe((products: Product[]) => {
      this.products = products;
    });
  }

  addToCart(product: Product) {
    // Implement your add to cart logic here
    console.log('Adding product to cart:', product);
    this.cartService.addToCart(product);

  }

  createPath(imgpath: string) {
    console.log('Creating path:', imgpath);
    var path = `https://localhost:7247/${imgpath.replace(/\\/g, '/')}`;
    //console.log(path);
    return path;
  }
  
}
