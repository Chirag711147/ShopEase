import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  name: string = "";
  email: string = "";
  password: string = "";
  username: string = "";
  age: string = "";
  address: string = "";
  gender: string = "";
  mobile: string = "";

  signInEmail: string = "";
  signInPassword: string = "";

  constructor(private http: HttpClient,private router:Router) { }

  ngOnInit(): void {
  }

  signUp(): void {
    const user = {
      name: this.name,
      email: this.email,
      password: this.password,
      username: this.username,
      age: this.age,
      address: this.address,
      gender: this.gender,
      mobile: this.mobile,
      role: "" // Empty string for role
    };
    this.http.post<any>('https://localhost:7247/api/Auth/signup', user)
      .subscribe(
        (response) => {
          console.log('Sign up successful!', response);
          localStorage.setItem('userId',response.userId);
          localStorage.setItem('token',response.token);
          this.router.navigate(["/"]);

        },
        (error) => {
          console.error('Error occurred during sign up:', error);
        }
      );
  }

  signIn(): void {
    const user = { email: this.signInEmail, password: this.signInPassword };
    this.http.post<any>('https://localhost:7247/api/Auth/login', user)
      .subscribe(
        (response) => {
          console.log('Sign in successful!', response);
          localStorage.setItem('userId',response.userId);
          localStorage.setItem('token',response.token);

          if(response.role=="admin"){

            this.router.navigate(["/admin/products"]);
          }
          else{

            this.router.navigate(["/"]);
          }
         
        },
        (error) => {
          console.error('Error occurred during sign in:', error);
        }
      );
  }

  toggleFormPanel(panel: string): void {
    const container = document.getElementById('container');
    if (panel === 'signUp') {
      container.classList.add("right-panel-active");
    } else if (panel === 'signIn') {
      container.classList.remove("right-panel-active");
    }
  }

}
