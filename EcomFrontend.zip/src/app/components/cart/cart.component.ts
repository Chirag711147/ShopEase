import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/Services/cart.service';
import { Order } from 'src/app/Services/order.model';
import { Product } from '../productsection/product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  totalAmount: number;
  today = new Date();
  expecteddel1 = new Date(this.today);
  expecteddel2 = new Date(this.today);

  orders: Product[] = []; 

  constructor(private cartService: CartService,private router:Router) {}

  ngOnInit(): void {
    this.fetchCartItems();
    this.totalAmt();
    this.getDeliveryDate();
  }

  //can use ngOnChanges

  getDeliveryDate(): void {
    let today = new Date();
    this.expecteddel1.setDate(today.getDate() + 4);
    this.expecteddel2.setDate(today.getDate() + 7);
  }

  totalAmt() {
    this.totalAmount = this.cartService.getTotalAmount();
  }

  fetchCartItems(): void {
    this.orders = this.cartService.getProductsInCart();
  }
  increaseQuantity(product: Product): void {
    this.cartService.updateQuantity(product.id, product.quantity + 1);
    this.fetchCartItems();
    this.totalAmt();
  }
  decreaseQuantity(product: Product): void {
    if (product.quantity - 1 <= 0) {
      alert('The Product will be removed from the Cart!!');
      this.removeFromCart(product);
    } else {
      this.cartService.updateQuantity(product.id, product.quantity - 1);
      this.fetchCartItems();
      this.totalAmt();
    }
  }
  checkout(): void {
    this.router.navigate(['/checkout']);
  }
  removeFromCart(product: Product): void {
    this.cartService.removeFromCart(product.id);
    this.fetchCartItems();
    this.totalAmt();
  }
  createPath(imgpath: string) {
    return `https://localhost:7247/${imgpath}`;
  }
}
