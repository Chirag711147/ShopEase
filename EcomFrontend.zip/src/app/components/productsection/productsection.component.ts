import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/Services/product.service';
import { Product } from './product.model';
import { CartService } from 'src/app/Services/cart.service';

@Component({
  selector: 'app-productsection',
  templateUrl: './productsection.component.html',
  styleUrls: ['./productsection.component.css']
})
export class ProductsectionComponent implements OnInit {

  bestSellers: Product[] = [];
  newArrivals: Product[] = [];
  hotSales: Product[] = [];

  constructor(private productService: ProductService,private cartService:CartService) {}

  ngOnInit(): void {
    this.fetchProducts();
  }

  fetchProducts() {
    this.productService.getProducts().subscribe((products: Product[]) => {
      // Shuffle the array of products randomly
      const shuffledProducts = this.shuffle(products);

      // Assign products to different categories
      const totalProducts = shuffledProducts.length;
      const portion = Math.floor(totalProducts / 3); // Divide the products equally into three categories
      this.bestSellers = shuffledProducts.slice(0, portion);
      this.newArrivals = shuffledProducts.slice(portion, portion * 2);
      this.hotSales = shuffledProducts.slice(portion * 2, totalProducts);
    });
  }

  shuffle(array: any[]): any[] {
    // Fisher-Yates shuffle algorithm
    let currentIndex = array.length;
    let temporaryValue;
    let randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
      // Pick a remaining element...
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      // And swap it with the current element.
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }

    return array;
  }

  addToCart(product: Product) {
    // Implement your add to cart logic here
    console.log('Adding product to cart:', product);
    this.cartService.addToCart(product);

  }

  createPath(imgpath: string) {
    //console.log('Creating path:', imgpath);
    var path = `https://localhost:7247/${imgpath.replace(/\\/g, '/')}`;
    //console.log(path);
    return path;
  }

}
