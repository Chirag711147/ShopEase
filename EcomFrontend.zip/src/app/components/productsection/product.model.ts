export class Product {
    id: number;
    name: string;
    catid: number;
    price: number;
    quantity: number;
    description: string;
    imagepath: string;
  }
  