import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { LandingpageComponent } from './components/landingpage/landingpage.component';
import { LogInComponent } from './components/log-in/log-in.component';
import { RegisterComponent } from './components/register/register.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularMaterialModule } from './angular-material.module';
import { AppRoutingModule } from './app-routing.module';
import { NavbarComponent } from './components/navbar/navbar.component';
import { OffcanvasmenuComponent } from './components/offcanvasmenu/offcanvasmenu.component';
import { HerosectionComponent } from './components/herosection/herosection.component';
import { FooterComponent } from './components/footer/footer.component';
import { LatestblogComponent } from './components/latestblog/latestblog.component';
import { InstagramsectionComponent } from './components/instagramsection/instagramsection.component';
import { DealsectionComponent } from './components/dealsection/dealsection.component';
import { ProductsectionComponent } from './components/productsection/productsection.component';
import { BannersectionComponent } from './components/bannersection/bannersection.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ShopComponent } from './components/shop/shop.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { CartComponent } from './components/cart/cart.component';
import { AdminModule } from './admin/admin.module';




@NgModule({
  declarations: [
    AppComponent,
    LandingpageComponent,
    LogInComponent,
    RegisterComponent,
    NavbarComponent,
    OffcanvasmenuComponent,
    HerosectionComponent,
    FooterComponent,
    LatestblogComponent,
    InstagramsectionComponent,
    DealsectionComponent,
    ProductsectionComponent,
    BannersectionComponent,
    ShopComponent,
    CheckoutComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class AppModule { }
