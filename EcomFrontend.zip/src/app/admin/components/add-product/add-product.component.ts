// add-product.component.ts

import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-add-product',
    templateUrl: './add-product.component.html',
    styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
    product: any = {
        name: '',
        catid: '',
        price: '',
        quantity: '',
        description: '',
        image: null
    };

    constructor(private http: HttpClient) { }

    onSubmit(): void {
        const formData = new FormData();
        formData.append('name', this.product.name);
        formData.append('catid', this.product.catid);
        formData.append('price', this.product.price);
        formData.append('quantity', this.product.quantity);
        formData.append('description', this.product.description);
        if (this.product.image) {
            formData.append('image', this.product.image);
        }

        this.http.post<any>('https://localhost:7247/api/Product/productupload', formData)
            .subscribe(
                () => {
                    console.log('Product added successfully');
                    alert('Product added successfully');
                },
                (error) => {
                    console.error('Error adding product:', error);
                }
            );
    }

    onFileSelected(event: any): void {
        if (event.target.files.length > 0) {
            const file = event.target.files[0];
            this.product.image = file;
        }
    }
}
