import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Services/product.model';
import { ProductService } from 'src/app/Services/product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products: Product[];

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts(): void {
    this.productService.getProducts()
      .subscribe(products => this.products = products);
  }

  createPath(imgpath: string) {
    // console.log('Creating path:', imgpath);
    var path = `https://localhost:7247/${imgpath.replace(/\\/g, '/')}`;
    //console.log(path);
    return path;
  }

  RemoveItem(productId: number): void {
    if (confirm('Are you sure you want to remove this product?')) {
      this.productService.deleteProduct(productId).subscribe(() => {
        // Filter out the removed product from the local array
        this.products = this.products.filter(product => product.id !== productId);
      });
    }
  }

}
