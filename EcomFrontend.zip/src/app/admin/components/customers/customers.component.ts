import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  customers: any[] = [];

    constructor(private http: HttpClient){ }

    ngOnInit(): void {
        this.fetchCustomers();
    }

    fetchCustomers(): void {
        this.http.get<any[]>('https://localhost:7247/api/Auth/users')
            .subscribe(
                (response) => {
                    this.customers = response;
                },
                (error) => {
                    console.error('Error fetching customers:', error);
                }
            );
    }

    

    
    


}
