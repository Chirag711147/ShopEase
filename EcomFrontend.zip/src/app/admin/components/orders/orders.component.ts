import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/Services/order.model';
import { OrderService } from 'src/app/Services/order.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  orders: Order[];

  constructor(private orderService: OrderService) { }

  ngOnInit(): void {
    this.getOrders();
  }

  getOrders(): void {
    this.orderService.getOrders()
      .subscribe(orders => this.orders = orders);
  }

  updateOrderStatus(orderId: string, event: any): void {
    const newStatus = event.target.value;
    this.orderService.updateOrderStatus(orderId, newStatus)
      .subscribe(() => {
        // Update the status of the order locally after successful update
        const orderToUpdate = this.orders.find(order => order.orderid === orderId);
        if (orderToUpdate) {
          orderToUpdate.status = newStatus;
        }
      });
  }
  

}
