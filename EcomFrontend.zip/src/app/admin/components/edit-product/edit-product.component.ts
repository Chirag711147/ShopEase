import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-edit-product',
    templateUrl: './edit-product.component.html',
    styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {
    productId: number;
    product: any = {
        name: '',
        catid: '',
        price: '',
        quantity: '',
        description: '',
        image: null
    };

    constructor(private http: HttpClient, private route: ActivatedRoute,private router:Router) { }

    ngOnInit(): void {
        this.productId = this.route.snapshot.params['id'];
        this.fetchProduct();
    }

    fetchProduct(): void {
        this.http.get<any>('https://localhost:7247/api/Product/' + this.productId)
            .subscribe(
                (response) => {
                    this.product = response;
                },
                (error) => {
                    console.error('Error fetching product:', error);
                }
            );
    }

    onSubmit(): void {
        const formData = new FormData();
        formData.append('name', this.product.name);
        formData.append('catid', this.product.catid);
        formData.append('price', this.product.price);
        formData.append('quantity', this.product.quantity);
        formData.append('description', this.product.description);
        if (this.product.image) {
            formData.append('image', this.product.image);
        }

        this.http.put<any>('https://localhost:7247/api/Product/editproductupload/' + this.productId, formData)
            .subscribe(
                () => {
                    console.log('Product updated successfully');
                    alert('Product updated successfully');
                    this.router.navigate(['/admin/products'])
                },
                (error) => {
                    console.error('Error updating product:', error);
                }
            );
    }

    onFileSelected(event: any): void {
        if (event.target.files.length > 0) {
            const file = event.target.files[0];
            this.product.image = file;
        }
    }
}
