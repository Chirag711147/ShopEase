// product.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../components/shop/product.model';
import { Category } from './category.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'https://localhost:7247/api/Product'; // Update this with your actual API URL

  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>("https://localhost:7247/api/Category");
  }

  deleteProduct(productId: number): Observable<void> {
    const url = `${this.apiUrl}?id=${productId}`;
    return this.http.delete<void>(url);
  }
  
  
}
