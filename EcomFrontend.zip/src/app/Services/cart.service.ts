import { Injectable } from '@angular/core';
import { Product } from './product.model';
import { Order } from './order.model';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private cartItemsKey = 'cartItems';
  private orderIdKey = 'orderId';
  private userIdKey = 'userId';
  private apiUrl = 'https://localhost:7247/api/Order';  

  constructor(private http: HttpClient, private router: Router) {}

  addToCart(product: Product): void {
    const userId = localStorage.getItem(this.userIdKey);
    if (userId) {
      let cartItems: Product[] =
        JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
      const existingProductIndex = cartItems.findIndex(item=>item.id === product.id);
      if(existingProductIndex !== -1){
        cartItems[existingProductIndex].quantity++;
      }
      else{
        product.quantity = 1;
        cartItems.push(product);

      }



      localStorage.setItem(this.cartItemsKey, JSON.stringify(cartItems));
      let orderId = localStorage.getItem(this.orderIdKey);
      if (!orderId) {
        orderId = this.generateOrderId();
        localStorage.setItem(this.orderIdKey, orderId);
      }
      alert('Product added to Cart successfully!!');
    } else {
      alert('You need to sign in first!!');
      this.router.navigate(['login']);
    }
  }

  getOrders(): Order[] {
    return JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
  }
  getProductsInCart(): Product[] {
    const cartItems: Product[] =
      JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
    return cartItems;
  }

  addToApi(orders: Order[]): void {
    orders.forEach((order) => {
      this.http.post(this.apiUrl, order).subscribe(
        () => console.log('Order added to API successfully'),
        (error) => console.error('Error adding order to API:', error)
      );
    });
  }
  checkout(): void {
    const cartItems: Product[] =
      JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
    const userId = localStorage.getItem(this.userIdKey);
    const orderId = localStorage.getItem(this.orderIdKey);

    if (userId && orderId && cartItems.length > 0) {
      const orders: Order[] = cartItems.map((item) => ({
        orderid: orderId,
        userid: parseInt(userId),
        pid: item.id,
        pname: item.name,
        quantity: item.quantity, // Assuming quantity is 1 when adding to cart
        price: item.price,
        status: 'pending',
      }));

      this.addToApi(orders);

      localStorage.removeItem(this.cartItemsKey);
    } else {
      console.error(
        'Unable to checkout: Missing user ID, order ID, or cart items'
      );
    }
  }
  updateQuantity(productId: number, quantity: number): void {
    const cartItems: Product[] =
      JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
    const index = cartItems.findIndex((item) => item.id === productId);
    if (index !== -1) {
      cartItems[index].quantity = quantity;
      localStorage.setItem(this.cartItemsKey, JSON.stringify(cartItems));
    } else {
      console.error('Product not found in cart:', productId);
    }
  }

  private generateOrderId(): string {
    // Generate a random order ID
    return Math.random().toString(36).substr(2, 9); // Example of generating a random alphanumeric string
  }

  removeFromCart(productId: number): void {
    let cartItems: Product[] =
      JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
    cartItems = cartItems.filter((cartItem) => cartItem.id != productId);
    localStorage.setItem(this.cartItemsKey, JSON.stringify(cartItems));
  }

  getTotalAmount(): number {
    let totalAmount = 0;
    const cartItems: Product[] =
      JSON.parse(localStorage.getItem(this.cartItemsKey)) || [];
    cartItems.forEach((cartItem) => {
      totalAmount += cartItem.price * cartItem.quantity;
    });
    return totalAmount;
  }
}
