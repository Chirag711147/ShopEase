export interface Order {
    orderid: string;
    userid: number;
    pid: number;
    pname: string;
    quantity: number;
    price: number;
    status: string;
  }
  