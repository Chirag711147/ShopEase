﻿namespace EcomApi.Models
{
    public class Order
    {
        public int id { get; set; }
        public string orderid { get; set; }
        public int userid { get; set; }

        public int pid { get; set; }
        public string pname { get; set; }
        public int quantity { get; set; }

        public int price { get; set; }

        public string status { get; set; }

    }
}
