﻿using System.ComponentModel.DataAnnotations;

namespace EcomApi.Models
{
    public class Product
    {
        public int id { get; set; }

        [Required] public string name { get; set; }
        [Required] public int catid { get; set; }

        [Required] public int price { get; set; }
        [Required] public int quantity { get; set; }
        [Required] public string description { get; set; }

        public string imagepath { get; set; }
    }
}
