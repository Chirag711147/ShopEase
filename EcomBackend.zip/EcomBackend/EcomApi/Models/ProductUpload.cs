﻿using System.ComponentModel.DataAnnotations;

namespace EcomApi.Models
{
    public class ProductUpload
    {
        [Required] public string name { get; set; }
        [Required] public string catid { get; set; }

        [Required] public string price { get; set; }
        [Required] public string quantity { get; set; }
        [Required] public string description { get; set; }

        public IFormFile image { get; set; }
    }
}
