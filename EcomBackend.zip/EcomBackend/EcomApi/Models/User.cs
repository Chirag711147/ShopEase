﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.DynamicLinq;

namespace EcomApi.Models
{
    [Index(nameof(email), IsUnique = true)]
    [Index(nameof(username), IsUnique = true)]
    public class User
    {
        public int id { get; set; }
        public string role { get; set; }

        [Required] public string name { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string password { get; set; }

        [Required]
        
        public string username { get; set; }

        [Required]
        public string age { get; set; }

        public string gender { get; set; }

        public string mobile { get; set; }
        public string address { get; set; }

        

        public DateTime createdAt { get; set; }





    }
}
