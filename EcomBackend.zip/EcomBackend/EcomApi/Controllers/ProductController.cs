﻿using EcomApi.Enitities;
using EcomApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EcomApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly ProductService _productService;
        public ProductController(ProductService productService)
        {
            _productService= productService;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            try
            {
                var result = await _productService.GetAllProducts();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPost]
        public async Task<IActionResult> AddProduct([FromBody]Product product)
        {
            try
            {
                await _productService.AddProduct(product);
                return Ok("Product added");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            
        }

        [HttpPut]
        public async Task<IActionResult> EditProduct(int id,[FromBody] Product product)
        {
            try
            {
                await _productService.UpdateProduct(id,product);
                return Ok("Product Updated");
            }
            catch
            (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            try
            {
                await _productService.DeleteProduct(id);
                return Ok("Product deleted");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("productupload")]
        public async Task<IActionResult> ProductUpload([FromForm] ProductUpload pu)
        {
            var result=await _productService.UploadProduct(pu);
            return Ok (result);
        }
        [HttpPost("editproductupload")]
        public async Task<IActionResult> EditProductUpload(int id,[FromForm] ProductUpload pu)
        {
            var result = await _productService.EditUploadProduct(id,pu);
            return Ok(result);
        }
        [HttpGet("categoryfilter")]//gt user by mail
        public async Task<IActionResult> FilterByCategory(int id)
        {
            var user = await _productService.FilterByCategory(id);
            if (user == null)
                return NotFound("User not found");

            return Ok(user);
        }
    }
}
