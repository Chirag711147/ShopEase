﻿using EcomApi.Enitities;
using EcomApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EcomApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly OrderService _orderservice;
        public OrderController(OrderService orderService)
        {
            _orderservice = orderService;
            
        }
        [HttpGet]
        public async Task<IActionResult> GetAllOrder()
        {
            try
            {
               var result=await _orderservice.GetAllOrders();
                return Ok(result);
               
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> AddOrder([FromBody]Order order)
        {
            try
            {
                await _orderservice.AddOrder(order);
                return Ok("Product added");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPut]
        public async Task<IActionResult> UpdateOrder(int id, [FromBody]Order order)
        {
            try
            {
                await _orderservice.UpdateOrder(id, order);
                return Ok("Order updated");
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            try
            {
                await _orderservice.DeleteOrder(id);
                return Ok("Order deleted");
            }
            catch(Exception ex)
            {
                return NotFound();
            }
        }
        [HttpPatch]
        public async Task<IActionResult> UpdateOrderStatus(int id,string status)
        {
            try
            {
                await _orderservice.UpdateOrderStatus(id, status);
                return Ok("Order status updated");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
