﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EcomApi.Data;
using EcomApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace EcomApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly JwtOption _options;
        public AuthController(AppDbContext context, IOptions<JwtOption> options)
        {
            _context = context;
            _options = options.Value;
        }
        [HttpPost("signup")]
        public async Task<IActionResult> SignUp([FromBody] User user)
        {
            if (!ModelState.IsValid || user == null)
                return BadRequest("Invalid user data");

            var sha1 = System.Security.Cryptography.SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(user.password));
            user.password = Convert.ToBase64String(hash);
            if(user.role == "")
            {
                user.role="user";
            }

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "User added successfully" });
        }

        private string GetJWTToken(string email)
        {
            var jwtKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.Key));
            var crendential = new SigningCredentials(jwtKey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim> { new Claim("Email", email) };
            var sToken = new JwtSecurityToken(_options.Key, _options.Issuer, claims, expires: DateTime.Now.AddHours(5), signingCredentials: crendential);
            return new JwtSecurityTokenHandler().WriteToken(sToken);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Login user)
        {
            if (user == null)
                return BadRequest("Invalid user data");

            var userData = await _context.Users.FirstOrDefaultAsync(x => x.email == user.email);
            if (userData == null)
                return BadRequest("User not found");

            var dbPassword = userData.password;
            var sha1 = System.Security.Cryptography.SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(user.password));
            if (dbPassword != Convert.ToBase64String(hash))
                return BadRequest("Incorrect Password!!");

            var token = GetJWTToken(user.email);
            return Ok(new { token });
        }

        [HttpGet("user/{email}")]//gt user by mail
        public async Task<IActionResult> GetUserByEmail(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.email == email);
            if (user == null)
                return NotFound("User not found");

            return Ok(user);
        }
        [HttpGet("{id}")]//to get user by id
        public async Task<IActionResult> GetUserById(int id)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.id == id);
            if (user == null)
                return NotFound("User not found");

            return Ok(user);
        }

        [HttpGet("users")]//get all users can be displayed in admin dashboard
        public async Task<IActionResult> GetAllUser()
        {
            var result=await _context.Users.ToListAsync();
            return Ok(result);
        }
        [HttpPut("userupdate")]
        public async Task<IActionResult> UpdateProfile(int id,[FromBody]User user)
        {
            var result = await _context.Users.FindAsync(id);
            if(result != null)
            {
                result.mobile = user.mobile;
                result.email=user.email;
                result.address=user.address;
                result.age = user.age;
                if(user.role=="")
                {
                    result.role = user.role;

                }
                else { }


            }

        }

        
    

}
}
