﻿using EcomApi.Data;
using EcomApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EcomApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly AppDbContext _context;
        public CategoryController(AppDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IActionResult> GetCategories()
        {
            try
            {
                var result = await _context.Categories.ToListAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> AddCategory([FromBody] Category cat)//remove frombody when sending frontend data
        {
            try
            {
                _context.Categories.Add(cat);
                await _context.SaveChangesAsync();
                return Ok("Category Added");
            }
            catch (Exception ex)
            {
               return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        public async Task<IActionResult> UpdateCategory(int id, [FromBody] Category category)
        {
            try
            {
                var result = await _context.Categories.FindAsync(id);
                result.name = category.name;
                await _context.SaveChangesAsync();
                return Ok("Category Updated");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            try
            {
                var result = await _context.Categories.FindAsync(id);
                _context.Categories.Remove(result);
                await _context.SaveChangesAsync();
                return Ok("Category deleted");
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
