﻿using System.Net.Http.Headers;
using EcomApi.Data;
using EcomApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;

namespace EcomApi.Enitities
{
    public class ProductService
    {
        private readonly AppDbContext _context;
        public ProductService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Product>> GetAllProducts()
        {
            return await _context.Products.ToListAsync();
        }

        public async Task AddProduct(Product product)
        {
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateProduct(int id, Product product)
        {
            var result = _context.Products.Find(id);
            if (result != null)
            {
                result.name = product.name;
                result.description = product.description;
                result.price = product.price;
                result.quantity = product.quantity;
                result.imagepath = product.imagepath;
                result.catid = product.catid;
            }
            await _context.SaveChangesAsync();
        }
        public async Task DeleteProduct(int id)
        {
            var result = await _context.Products.FindAsync(id);
            _context.Products.Remove(result);
            await _context.SaveChangesAsync();
        }

        public async Task<string> UploadProduct(ProductUpload pu)
        {
            var file = pu.image;
            var folderName = Path.Combine("Resources", "Images");
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            if (file.Length > 0)
            {
                var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                var dbPath = Path.Combine(folderName, fileName);
                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }


                var product = new Product
                {
                    name = pu.name,
                    description = pu.description,
                    price = int.Parse(pu.price),
                    quantity = int.Parse(pu.quantity),
                    imagepath = dbPath,
                    catid = int.Parse(pu.catid)


                };

                _context.Products.Add(product);
                await _context.SaveChangesAsync();
                return "Product added successfully";
            }
            return "Not added check error";


        }
        public async Task<string> EditUploadProduct(int id,ProductUpload pu)
        {
            var file = pu.image;
            var folderName = Path.Combine("Resources", "Images");
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            if (file.Length > 0)
            {
                var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                var dbPath = Path.Combine(folderName, fileName);
                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }


                var product = _context.Products.Find(id);


                product.name = pu.name;
                product.description = pu.description;
                product.price = int.Parse(pu.price);
                product.quantity = int.Parse(pu.quantity);
                product.imagepath = dbPath;
                product.catid = int.Parse(pu.catid);

                await _context.SaveChangesAsync();
                return "Product added successfully";
            }
            return "Not added check error";


        }
        public async Task<List<Product>> FilterByCategory(int catidsupply)
        {
            List<Product> products = new List<Product>();
            foreach (var item in _context.Products)
            {
                if (item.catid == catidsupply)
                {
                    products.Add(item);
                }
            }
            return products;
        }
    }
}
