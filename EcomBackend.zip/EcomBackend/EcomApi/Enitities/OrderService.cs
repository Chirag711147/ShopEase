﻿using EcomApi.Data;
using EcomApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EcomApi.Enitities
{
    public class OrderService
    {
        private readonly AppDbContext _context;
        public OrderService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Order>> GetAllOrders()
        {
            return await _context.Orders.ToListAsync();
        }
        public async Task AddOrder(Order order)
        {
            if(order.status=="")
            {
                order.status = "Pending";
            }
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateOrder(int id,Order order)
        {

            var result= await _context.Orders.FindAsync(id);
            result.userid=order.userid;
            result.orderid=order.orderid;
            result.price=order.price;
            result.quantity=order.quantity;
            result.pname=order.pname;
            result.pid=order.pid;
            if(order.status=="")
            {
                result.status = "Pending";
            }
            else
            {

            result.status=order.status;
            }
            await _context.SaveChangesAsync();
        }
        public async Task DeleteOrder(int id)
        {
            var result = await _context.Orders.FindAsync(id);
            _context.Orders.Remove(result);
            await _context.SaveChangesAsync();
        }

        //create one api call just to change status of the order
        public async Task UpdateOrderStatus(int id,string status)
        {
            var result= await _context.Orders.FindAsync(id);
            result.status = status;
           await _context.SaveChangesAsync();
           
        }
    }
}
