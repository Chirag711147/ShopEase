﻿namespace healthcare_api.Models
{
    public class User
    {
        public int id { get; set; }
        public string fname { get; set; } = string.Empty;
        public string lname { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
        public string password { get; set; } = string.Empty;
        public int age { get; set; }
        public string gender { get; set; } = string.Empty;
        public string phone { get; set; } = string.Empty;

        public string address { get; set; } = string.Empty;
        public string profilePhoto { get; set; } = string.Empty;

        public Role Roles { get; set; }
        public int RoleId { get; set; }


    }
}
