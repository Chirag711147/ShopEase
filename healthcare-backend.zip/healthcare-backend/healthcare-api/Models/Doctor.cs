﻿namespace healthcare_api.Models
{
    public class Doctor
    {
        public int id { get; set; }
        public int userId { get; set; }
        public string name { get; set; } = string.Empty;
        public string speciality { get; set; } = string.Empty;
        public string location { get; set; } = string.Empty;
        public string experience { get; set; } = string.Empty;
        public string image {  get; set; } = string.Empty;
        public string degree { get; set; } = string.Empty;
        public string[]? days { get; set;}
        public string startTime { get; set; } = string.Empty;
        public string endTime { get; set; } = string.Empty;
    }
}
