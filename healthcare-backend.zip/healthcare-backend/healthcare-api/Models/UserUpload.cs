﻿namespace healthcare_api.Models
{
    public class UserUpload
    {
        public int id { get; set; }
        public string fname { get; set; } = string.Empty;
        public string lname { get; set; }=string.Empty;
        public string email { get; set; } = string.Empty;
        public string password { get; set; } = string.Empty;
        public string cpassword {  get; set; } = string.Empty;
        public int age { get; set; }
        public string gender { get; set; } = string.Empty;
        public string phone { get; set; } = string.Empty;

        public string address { get; set; } = string.Empty;
        public required IFormFile profilePhoto { get; set; }
    }
}
