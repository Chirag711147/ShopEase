﻿namespace healthcare_api.Models
{
    public class updateUser
    {
        public string fname { get; set; } = string.Empty;
        public string lname { get; set; } = string.Empty;
        public int age { get; set; }
        public string gender { get; set; } = string.Empty;
        public string phone { get; set; } = string.Empty;

        public string address { get; set; } = string.Empty;

        public required IFormFile profilePhoto { get; set; }

    }
}
