﻿using System.ComponentModel.DataAnnotations.Schema;

namespace healthcare_api.Models
{
    public class Role
    {
        public int Id { get; set; }
        //public int userId { get; set; }
        public string RoleName { get; set; }
        //public User User { get; set; 
    }
}
