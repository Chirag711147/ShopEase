﻿namespace healthcare_api.Models
{
    public class JwtOption
    {
        public string Key { get; set; }
        public string Issuer { get; set; }
    }
}
