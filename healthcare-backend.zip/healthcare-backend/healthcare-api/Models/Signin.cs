﻿namespace healthcare_api.Models
{
    public class Signin
    {
        public string email { get; set; }
        public string password { get; set; }
    }

}
