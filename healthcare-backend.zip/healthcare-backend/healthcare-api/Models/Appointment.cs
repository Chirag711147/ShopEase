﻿namespace healthcare_api.Models
{
    public class Appointment
    {
        public int id { get; set; }
        public int userId { get; set; }
        public int doctorId {  get; set; }
        public DateOnly date { get; set; }

        public TimeOnly time { get; set; }

    }
}
