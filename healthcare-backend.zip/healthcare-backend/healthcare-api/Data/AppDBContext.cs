﻿using healthcare_api.Models;
using Microsoft.EntityFrameworkCore;

namespace healthcare_api.Data
{
    public class AppDBContext:DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options):base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Doctor> Doctors { get; set; }

        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<Role> Roles { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<User>().HasOne(r => r.Roles).WithOne(u => u.User).HasForeignKey<Role>(u => u.userId);
        //    base.OnModelCreating(modelBuilder);
        //}
    }
}
