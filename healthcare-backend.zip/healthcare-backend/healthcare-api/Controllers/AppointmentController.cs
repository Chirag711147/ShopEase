﻿using healthcare_api.Data;
using healthcare_api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace healthcare_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AppointmentController : ControllerBase
    {
        private readonly AppDBContext _context;
        public AppointmentController(AppDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<IActionResult> GetAppointments()
        {
            var result =await _context.Appointments.ToListAsync();
            return Ok(result);
        }
        [HttpPost]
        public async Task<IActionResult> PostAppointment(Appointment app)
        {
            if(app == null)
            {
                return BadRequest("Data not valid");
            }
            _context.Appointments.Add(app);
            await _context.SaveChangesAsync();
            return Ok("Appointment Scheduled");
        }
    }
}
