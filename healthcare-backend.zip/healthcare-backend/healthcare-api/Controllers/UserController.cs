﻿using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using healthcare_api.Data;
using healthcare_api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Net.Http.Headers;

namespace healthcare_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class UserController : ControllerBase
    {
        private readonly AppDBContext _context;
        private readonly JwtOption _options;

        public UserController(AppDBContext context, IOptions<JwtOption> options)
        {
            _context = context;
            _options = options.Value;

        }

        [HttpPost("signup")]
        public async Task<IActionResult> Signup(UserUpload user)
        {
            if (!ModelState.IsValid || user == null)
            {
                return BadRequest("Invalid user data");

            }
            if (user.password != user.cpassword)
            {
                return BadRequest("Confirm password does not matches Password");

            }
            var sha1 = System.Security.Cryptography.SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(user.password));
            user.password = Convert.ToBase64String(hash);
            //create image path from image
            var profilePhotoPath = "";
            var file = user.profilePhoto;
            var folderName = Path.Combine("Resources", "Images");
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            if (file.Length > 0)
            {
                var fileName = System.Net.Http.Headers.ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);

                var dbPath = Path.Combine(folderName, fileName);
                profilePhotoPath = dbPath;
                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }


            }

            User addNewUser = new User();
            addNewUser.fname = user.fname;
            addNewUser.lname = user.lname;
            addNewUser.email = user.email;
            addNewUser.password = user.password;
            addNewUser.address = user.address;
            addNewUser.age = user.age;
            addNewUser.phone = user.phone;
            addNewUser.profilePhoto = profilePhotoPath;
            addNewUser.gender = user.gender;
            addNewUser.RoleId = 1;

            _context.Users.Add(addNewUser);
            await _context.SaveChangesAsync();
            var userStored = await _context.Users.FirstOrDefaultAsync(u => u.email == user.email);
            var token = GetJWTToken(addNewUser.email);
            return Ok(new { userId = userStored.id, token = token });

        }
        [NonAction]
        public string GetJWTToken(string email)
        {
            var jwtkey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.Key));
            var credential = new SigningCredentials(jwtkey, SecurityAlgorithms.HmacSha256);
            var claims = new List<Claim> { new Claim("Email", email) };
            var sToken = new JwtSecurityToken(_options.Key, _options.Issuer, claims, expires: DateTime.Now.AddHours(5), signingCredentials: credential);
            return new JwtSecurityTokenHandler().WriteToken(sToken);
        }
        [HttpPost("Signin")]
        public async Task<IActionResult> Signin(Signin user)
        {
            if (user == null)
            {
                return BadRequest("Invalid user data");
            }
            var userData = await _context.Users.FirstOrDefaultAsync(x => x.email == user.email);
            if (userData == null)
            {
                return BadRequest("User Not Found");
            }
            var dbPassword = userData.password;
            var sha1 = System.Security.Cryptography.SHA1.Create();
            var hash = sha1.ComputeHash(Encoding.UTF8.GetBytes(user.password));
            if (dbPassword != Convert.ToBase64String(hash))
            {
                return BadRequest("Incorrect Password!!");
            }
            var token = GetJWTToken(user.email);
            var role = _context.Roles.Find(userData.RoleId);
            var roleName = role.RoleName;
            if(roleName=="doctor")
            {
                var doctor =await _context.Doctors.FirstOrDefaultAsync(doctor => doctor.userId == userData.id);
                if( doctor ==null)
                {
                    return BadRequest("Cannot find corresponding doctor records");
                }
                return Ok(new { userId = userData.id, token = token, role = roleName,doctorId=doctor.id });
            }
            return Ok(new { userId = userData.id, token = token,role=roleName });
        }


        [HttpPatch("updateProfile/{id}")]
        public async Task<IActionResult> UpdateProfile(int id, updateUser user)
        {
            if (user == null)
            {
                return BadRequest("Data not Valid");
            }
            var result = await _context.Users.FindAsync(id);
            if (result == null)
            {
                return BadRequest("User not found");
            }

            var profilePhotoPath = "";
            var file = user.profilePhoto;
            var folderName = Path.Combine("Resources", "Images");
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            if (file.Length > 0)
            {
                var fileName = System.Net.Http.Headers.ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);

                var dbPath = Path.Combine(folderName, fileName);
                profilePhotoPath = dbPath;
                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }


            }
            result.fname = user.fname;
            result.lname = user.lname;
            result.age = user.age;
            result.gender = user.gender;
            result.phone = user.phone;
            result.address = user.address;
            result.profilePhoto = profilePhotoPath;

            await _context.SaveChangesAsync();
            return Ok(result);

        }

        [Authorize]

        [HttpGet("UserInfo/{id}")]
        public async Task<IActionResult> GetUserInfo(int id)
        {
            var result = await _context.Users.FirstOrDefaultAsync(u => u.id == id);
            return Ok(result);
        }

        [HttpPost("role")]
        public async Task<IActionResult> AssignRoleToUser(Role role)
        {
            

            _context.Roles.Add(role);
            await _context.SaveChangesAsync();
            return Ok("Role created");
        }

        [HttpPatch]
        public async Task<IActionResult> UpdateRole(int userId,int roleId)
        {
            var role = await _context.Roles.FindAsync(roleId);
            if (role == null)
            {
                return BadRequest("Role not found");
            }
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
            {
                return BadRequest("User not found");
            }
            user.RoleId= roleId;
            await _context.SaveChangesAsync();
            return Ok("User Updated");
            
        }

        //[HttpGet("role/{userId}")]
        //public async Task<IActionResult> GetUserRole(int userId)
        //{
        //    var roles = await _context.Roles.Where(r => r.userId == userId).ToListAsync();

        //    if (roles == null || !roles.Any())
        //    {
        //        return NotFound();
        //    }

        //    return Ok(roles);
        //}

        [HttpGet("AllUsers")]
        [Authorize]
        public async Task<IActionResult> GetUsers()
        {
            var result = await _context.Users.Include(u => u.Roles).ToListAsync();
            if (result == null)
            {
                return BadRequest();
            }
            return Ok(result);
        }
        


    }
}
