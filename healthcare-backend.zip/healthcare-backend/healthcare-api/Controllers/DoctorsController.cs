﻿using healthcare_api.Data;
using healthcare_api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace healthcare_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorsController : ControllerBase
    {
        private readonly AppDBContext _context;
        public DoctorsController(AppDBContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<IActionResult> CreateDoctorProfile(Doctor doctor)
        {
            if(doctor == null)
            {
                return BadRequest("Doctor data not valid");
            }
            _context.Doctors.Add(doctor);
            await _context.SaveChangesAsync();
            return Ok("Doctor Profile is create");


        }
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetDoctors()
        {
            var result = await _context.Doctors.ToListAsync();
            return Ok(result);
        }
    }
}
