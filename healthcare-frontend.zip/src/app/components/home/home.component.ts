import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  scheduleCallForm=new FormGroup(
    {
      name: new FormControl('',Validators.required),
      email: new FormControl('',[Validators.required, Validators.email]),
      phone: new FormControl('',[Validators.required, Validators.minLength(10),Validators.maxLength(10)]),
      date: new FormControl('',Validators.required)
    }
  );


  constructor(private toastr: ToastrService) { }

  ngOnInit(): void {
  }

  scheduleCall(){
    console.log(this.scheduleCallForm.value);
    this.toastr.success('Your call has been scheduled successfully', "Congratulations");

  }

}
