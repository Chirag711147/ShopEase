import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs';
import { AppointmentsService } from 'src/app/services/appointments.service';
import { DoctorService } from 'src/app/services/doctor.service';

@Component({
  selector: 'app-appointment-listing',
  templateUrl: './appointment-listing.component.html',
  styleUrls: ['./appointment-listing.component.css'],
})
export class AppointmentListingComponent implements OnInit {
  constructor(
    private appointmentService: AppointmentsService,
    private doctorService: DoctorService
  ) {}
  appointmentList: any[] = [];
  doctors: any[] = [];
  filteredAppointmentList: any[] = [];
  combinedArrays: any[] = [];

  ngOnInit(): void {
    this.getAppointments();

    this.getDoctors();
  }

  getAppointments() {
    this.appointmentService
      .getAppointments()
      .pipe()
      .subscribe((data) => {
        this.appointmentList = data;
        console.log(this.appointmentList);
        sessionStorage.setItem(
          'appointmentList',
          JSON.stringify(this.appointmentList)
        );
      });
    // console.log("after loop");
    // console.log(this.appointmentList);
  }

  getDoctors() {
    this.doctorService.getDoctors().subscribe((data) => {
      this.doctors = data;
      sessionStorage.setItem('doctors', JSON.stringify(this.doctors));
    });
    console.log('doctors' + this.doctors);
    this.combinedList();
  }

  combinedList() {
    var appointments = JSON.parse(
      sessionStorage.getItem('appointmentList') || ''
    );
    var doctors = JSON.parse(sessionStorage.getItem('doctors') || '');
    var storedUserId = sessionStorage.getItem('user');
    console.log('userid stored userId: ' + storedUserId);

    appointments.forEach((appointment: any) => {
      if (appointment.userId ==storedUserId) {
        console.log('matched id');
        var doctor = doctors.find(
          (doctor: any) => doctor.id === appointment.doctorId
        );
        var date = new Date(appointment.date).toDateString();
        var result = {
          appointmentid: appointment.id,
          doctorId: appointment.doctorId,
          date: date,
          time: appointment.time,
          doctorName: doctor.name,
          doctorLocation: doctor.location,
          doctorSpeciality: doctor.speciality,
          doctorExperience: doctor.experience,
          doctorDegree: doctor.degree,
          doctorImage: doctor.image,
        };
        this.combinedArrays.push(result);
      }
      
    });
    console.log(this.combinedArrays);
  }
}
