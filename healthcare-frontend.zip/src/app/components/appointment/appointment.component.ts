import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { AppointmentsService } from 'src/app/services/appointments.service';
import { DoctorService } from 'src/app/services/doctor.service';
@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css'],
})
export class AppointmentComponent implements OnInit {
  /*   doctors:any[]= [
    {id:1, name: 'Dr. Anand Kumar', speciality: 'Cardiology', location: 'Gurugram', experience: '5', image: '../../../assets/images/doctor1.png', degree:'Mbbs', days: ["Mon","Thr"], startTime: '09:00', endTime: '17:00'},
    {id:2, name: 'Dr. Aarti Jha', speciality: 'Cardiology', location: 'Gurugram', experience: '5', image: '../../../assets/images/doctor2.png', degree:'Mbbs', days: ["Mon","Fri"], startTime: '09:00', endTime: '17:00'},
    {id:3, name: 'Dr. Sankesh Tiwari', speciality: 'Cardiology', location: 'Gurugram', experience: '5', image: '../../../assets/images/doctor3.png', degree:'Mbbs', days: ["Mon","Wed"], startTime: '09:00', endTime: '17:00'},
  ]; */

  doctors: any[] = [];

  scheduleAppointmentForm = new FormGroup({
    date: new FormControl('', Validators.required),
    time: new FormControl('', Validators.required),
  });

  doctor: any;

  timeslots: any[] = [];
  status: boolean = false;
  conditonChecTime = '';
  selectedTime: any;
  appointmentData: any = { userId: '', doctorId: '', date: '', time: '' };

  constructor(
    private doctorService: DoctorService,
    private toastr: ToastrService,
    private appointmentService: AppointmentsService
  ) {
    this.scheduleAppointmentForm.controls.date.valueChanges.subscribe(
      (data) => {
        if (data == null || !data) {
          return;
        }

        let datecheck = new Date(data);
        // console.log(datecheck.toDateString());

        // console.log(datecheck.getDay());
        // let day = date.toLocaleString('en-us', { weekday: 'long' });
        // console.log(Number(datecheck.getDate()));
        // console.log("check");
        // var date = moment(d, 'YYYY-MM-DD');
        // console.log(date);
        // let day = date.toString();
        // console.log(day);
        // var day=(datecheck.getDay());
        // console.log(typeof day);

        var daysArr = this.doctor.days;
        var i: number;
        var available = false;
        daysArr.forEach((element: any) => {
          console.log(element);
          for (i = 0; i < 3; i++) {
            if (true) {
              if (element[i] != datecheck.toDateString()[i]) {
                console.log(
                  element[i] + ' is not equal to ' + datecheck.toDateString()[i]
                );
                break;
              }
            }
          }
          if (i == 3) {
            console.log('doc available on' + element);
            available = true;
            //this.toastr.success('Doctor is available for this date!!');
          } else {
            console.log('i:' + i);
            //this.toastr.error('Sorry, this doctor is available for '+ JSON.stringify(this.doctor.days));
            console.log('doc not available on' + element);
          }
        });

        if (available) {
          var today = new Date();
          if (datecheck.toISOString() < today.toISOString()) {
            this.toastr.error('You cannot book appointment in past date!!');
            this.scheduleAppointmentForm.reset();
            return;
          }
          this.toastr.success('Doctor is available for this date!!');
        } else {
          this.toastr.error(
            'Sorry, this doctor is available for ' +
              JSON.stringify(this.doctor.days.join(','))
          );
          this.scheduleAppointmentForm.reset();
        }
      }
    );
  }

  ngOnInit(): void {
    this.doctorService.getDoctors().subscribe((data) => {
      console.table(data);
      this.doctors = data;
    });
    this.createTimeSlots();
  }

  scheduleAppointment() {
    console.log(this.scheduleAppointmentForm.value);
    this.toastr.success(
      'Your call has been scheduled successfully',
      'Congratulations'
    );
    this.appointmentData.userId = sessionStorage.getItem('user');
    this.appointmentData.doctorId = this.doctor.id;
    this.appointmentData.date = this.scheduleAppointmentForm.value.date;
    this.appointmentData.time = this.selectedTime;
    console.log(this.appointmentData);
    this.appointmentService
      .postAppointment(this.appointmentData)
      .subscribe((data) => {
        console.log(data);
      });
  }

  createTimeSlots() {
    var startTime = moment().utc().set({ hour: 10, minute: 0 });
    var endTime = moment().utc().set({ hour: 18, minute: 59 });

    var timeStops = [];

    while (startTime <= endTime) {
      timeStops.push(new (moment as any)(startTime).format('HH:mm'));
      startTime.add(30, 'minutes');
    }
    this.timeslots = timeStops;
  }

  bookAppointment(doctor: any) {
    this.doctor = doctor;
  }

  slotSelected(time: any) {
    this.scheduleAppointmentForm.controls.time.setValue(time);
    this.status = true;
    this.selectedTime = time;
    this.conditonChecTime = time;
    this.selectedTime += ':00';
  }
}
