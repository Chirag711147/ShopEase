import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {

  registerForm=new FormGroup(
    {
      fname: new FormControl('',Validators.required),
      lname: new FormControl('', Validators.required),
      age: new FormControl('',Validators.required),
      phone: new FormControl('',Validators.required),
      gender: new FormControl('',Validators.required),
      address: new FormControl(''),
      profilePhoto: new FormControl('')      
    });

    existingProfile:any;

    filepath:any="";

    constructor(private auth: AuthService, private route: Router) { }

    ngOnInit(): void {
      this.auth.userInfo().subscribe(
              (res)=>{
                this.existingProfile=res;
                this.registerForm.controls['fname'].setValue(this.existingProfile.fname);
                this.registerForm.controls['lname'].setValue(this.existingProfile.lname);
                this.registerForm.controls['age'].setValue(this.existingProfile.age);
                this.registerForm.controls['phone'].setValue(this.existingProfile.phone);
                this.registerForm.controls['gender'].setValue(this.existingProfile.gender);
                this.registerForm.controls['address'].setValue(this.existingProfile.address);
              },
              (err)=>{
                console.log(err);
              }
            );
    }
  
    uploadImage(event:any){
      if(event.target.files.length>0){
        console.log(event.target.files[0]);
        this.registerForm.controls['profilePhoto'].setValue(event.target.files[0]);
        this.filepath=event.target.files[0];
  
      }
      
    }
  
    editProfile(){
      console.log(this.registerForm.value);
      var editProfileData=new FormData();
      editProfileData.append('fname',this.registerForm.value.fname || "");
      editProfileData.append('lname',this.registerForm.value.lname || "");
      editProfileData.append('age',this.registerForm.value.age || "");
      editProfileData.append('phone',this.registerForm.value.phone || "");
      editProfileData.append('gender',this.registerForm.value.gender || "");
      editProfileData.append('address',this.registerForm.value.address || "");
      editProfileData.append('profilePhoto',this.filepath,this.filepath.name);
      
      this.auth.editProfile(editProfileData).subscribe(
            (res)=>{
              console.log(res);
              
              this.route.navigate(['/profile']);
            },
            (err)=>{
              console.log(err);
            }
          );
  
    }


}
