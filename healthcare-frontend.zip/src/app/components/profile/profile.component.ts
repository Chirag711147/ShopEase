import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

   /* Create a model for the user */
  /* user = {
    fname: '',
    lname: '',
    email: '',
    age: '',
    password: '',
    cpassword: '',
    phone: '',
    gender: '',
    address: '',
    profilePhoto: ''
  } */
/*   user = {
    fname: 'Anand',
    lname: 'Kumar',
    email: 'anand@gmail.com',
    age: '23',
    phone: '9899898989',
    gender: 'Male',
    address: 'Gurugram',
    profilePhoto: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2K6dSK2LTI1l_AT9SOROl9MTBJzUuaNEzWQ&s'
  } */

  user:any;

  constructor(private auth: AuthService) { }

  ngOnInit(): void {
    this.auth.userInfo().subscribe(
      (res)=>{
        this.user=res;
        console.log(this.user);
      },
      (err)=>{
        console.log(err);
      }
    );
  }

}
