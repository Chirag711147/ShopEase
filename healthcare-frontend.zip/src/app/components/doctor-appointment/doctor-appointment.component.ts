import { Component, OnInit } from '@angular/core';
import { AppointmentsService } from 'src/app/services/appointments.service';
import { AuthService } from 'src/app/services/auth.service';
import { DoctorService } from 'src/app/services/doctor.service';

@Component({
  selector: 'app-doctor-appointment',
  templateUrl: './doctor-appointment.component.html',
  styleUrls: ['./doctor-appointment.component.css'],
})
export class DoctorAppointmentComponent implements OnInit {
  constructor(
    private appointmentService: AppointmentsService,
    private doctorService: DoctorService,
    private userService: AuthService
  ) {}
  appointmentList: any[] = [];
  Users: any[] = [];
  filteredAppointmentList: any[] = [];
  combinedArrays: any[] = [];
  isDisplayed = false;

  ngOnInit(): void {
    this.getAppointments();

    this.getUsers();
  }

  getAppointments() {
    this.appointmentService
      .getAppointments()
      .pipe()
      .subscribe((data) => {
        this.appointmentList = data;
        console.log(this.appointmentList);
        sessionStorage.setItem(
          'appointmentList',
          JSON.stringify(this.appointmentList)
        );
      });
    // console.log("after loop");
    // console.log(this.appointmentList);
  }

  getUsers() {
    this.userService.getAllUsers().subscribe((data) => {
      this.Users = data;
      sessionStorage.setItem('Users', JSON.stringify(this.Users));
      console.log("users in the subscribe"+ this.Users)
    });
    
    console.log('Users' + this.Users);
    this.combinedList();
  }

  combinedList() {
    var appointments = JSON.parse(
      sessionStorage.getItem('appointmentList') || ''
    );
    var users = JSON.parse(sessionStorage.getItem('Users') || '');
    var storedDoctorId =sessionStorage.getItem('doctorId');
    console.log('userid stored userId: ' + storedDoctorId);

    appointments.forEach((appointment: any) => {
      if (appointment.doctorId == storedDoctorId) {
        console.log('matched id');
        var user = users.find(
          (user: any) => user.id === appointment.userId
        );
        var date = new Date(appointment.date).toDateString();
        var result = {
          appointmentid: appointment.id,
          doctorId: appointment.doctorId,
          date: date,
          time: appointment.time,
          userName: user.fname+" "+user.lname,
          userAge: user.age,
          userGender: user.gender,
          userPhone: user.phone,
          userAddress: user.address,
          userImage: user.profilePhoto,
        };
        this.combinedArrays.push(result);
      }
    });
    if(this.combinedArrays.length)
      {

        this.isDisplayed=true;
      }
    console.log(this.combinedArrays);
    
  }
}
