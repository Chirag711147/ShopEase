import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctors',
  templateUrl: './doctors.component.html',
  styleUrls: ['./doctors.component.css']
})
export class DoctorsComponent implements OnInit {
  //doctors array that hold name and specilisation information
  doctors = [
    {name: "Dr. John", specilisation: "Cardiologist", imgurl:"https://www.felixhospital.com/sites/default/files/2022-11/dr-dk-gupta.jpg"},
    {name: "Dr. Jane", specilisation: "Cardiologist" ,imgurl:"https://www.felixhospital.com/sites/default/files/2022-11/dr-dk-gupta.jpg"},
    {name: "Dr. Peter", specilisation: "Cardiologist",imgurl:"https://www.felixhospital.com/sites/default/files/2022-11/dr-dk-gupta.jpg"},
    {name: "Dr. Mary", specilisation: "Cardiologist",imgurl:"https://www.felixhospital.com/sites/default/files/2022-11/dr-dk-gupta.jpg"},
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
