import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {

  constructor(private auth: AuthService, private route: Router, private formBuilder: FormBuilder) {}

  registerForm = new FormGroup({
    fname: new FormControl('', Validators.required),
    lname: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    age: new FormControl('', Validators.required),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(8),
    ]),
    cpassword: new FormControl('', [
      Validators.required,
      Validators.minLength(8),
      
    ]),
    phone: new FormControl('', Validators.required),
    gender: new FormControl('', Validators.required),
    address: new FormControl(''),
    profilePhoto: new FormControl(''),
  });

  filepath: any = '';

  

  ngOnInit(): void {}

  uploadImage(event: any) {
    if (event.target.files.length > 0) {
      console.log(event.target.files[0]);
      if (event.target.files[0].size > 3000000) {
        alert('File size should be less than 3MB');
        event.target.value = '';
        return;
      }
      if (!['image/png', 'image/jpeg'].includes(event.target.files[0].type)) {
        alert('Only PNG or JPEG images are supported');
        event.target.value = '';
        return;
      }
      this.registerForm.controls['profilePhoto'].setValue(
        event.target.files[0]
      );
      this.filepath = event.target.files[0];
    }
  }

  register() {
    console.log(this.registerForm.value);
    var singupData = new FormData();
    singupData.append('fname', this.registerForm.value.fname || '');
    singupData.append('lname', this.registerForm.value.lname || '');
    singupData.append('email', this.registerForm.value.email || '');
    singupData.append('age', this.registerForm.value.age || '');
    singupData.append('password', this.registerForm.value.password || '');
    singupData.append('cpassword', this.registerForm.value.cpassword || '');
    singupData.append('phone', this.registerForm.value.phone || '');
    singupData.append('gender', this.registerForm.value.gender || '');
    singupData.append('address', this.registerForm.value.address || '');
    singupData.append('profilePhoto', this.filepath, this.filepath.name);

    this.auth.register(singupData).subscribe(
      (res) => {
        console.log(res);
        sessionStorage.setItem('isSignedIn', 'true');
        sessionStorage.setItem('user', JSON.stringify(res.userId));
        sessionStorage.setItem('token', res.token);
        this.route.navigate(['']);
      },
      (err) => {
        console.log(err);
      }
    );
  }

 
 
}
