import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  singinForm= new FormGroup(
    {
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required])
    }
  );

  constructor(private auth:AuthService,private route:Router,private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  signin(){
    console.log(this.singinForm.value);
    this.auth.singnin(this.singinForm.value).subscribe(res=>{
      console.log(res);
      sessionStorage.setItem('isSignedIn', 'true');
      sessionStorage.setItem('user', JSON.stringify(res.userId));
      sessionStorage.setItem('token', res.token);
      sessionStorage.setItem('role', res.role);
      sessionStorage.setItem('doctorId', res.doctorId);

      this.route.navigate(['']);
      this.toastr.success('Welcome Back!!');
    });
  }

}
