import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { DoctorsComponent } from './components/doctors/doctors.component';
import { AppointmentComponent } from './components/appointment/appointment.component';
import { SigninComponent } from './components/signin/signin.component';
import { SignupComponent } from './components/signup/signup.component';
import { ProfileComponent } from './components/profile/profile.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { AppointmentListingComponent } from './components/appointment-listing/appointment-listing.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { ServicesComponent } from './components/services/services.component';
import { NewsComponent } from './components/news/news.component';
import { DoctorAppointmentComponent } from './components/doctor-appointment/doctor-appointment.component';

const routes: Routes = [
  {path:"", component: HomeComponent},
  {path:"doctors", component: DoctorsComponent},
  {path:"appointments", component: AppointmentComponent},
  {path: "signin", component: SigninComponent},
  {path: "signup" ,component: SignupComponent},
  {path: "profile" ,component: ProfileComponent},
  {path: "editProfile" , component: EditProfileComponent},
  {path:"appointmentListing", component: AppointmentListingComponent},
  {path: "aboutus", component: AboutusComponent},
  {path: "services", component: ServicesComponent},
  {path: "news", component: NewsComponent},
  {path: "doctorappointment", component:DoctorAppointmentComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
