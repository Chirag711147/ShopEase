import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  api_url="https://localhost:7191";

  constructor(private http: HttpClient) { }

  singnin(singinData:any): Observable<any> {
    return this.http.post(this.api_url + "/api/User/Signin",singinData);
  }

  register(signupData:any): Observable<any> {
    return this.http.post(this.api_url + "/api/User/signup",signupData);
  }

  userInfo():Observable<any>{
    var userId=sessionStorage.getItem('user');
    console.log(userId);
    return this.http.get(this.api_url + `/api/User/UserInfo/${userId}`);
  }

  editProfile(editProfileData:any):Observable<any>{
    var userId=sessionStorage.getItem('user');
    return this.http.patch(this.api_url + `/api/User/updateProfile/${userId}`,editProfileData);
  }

  getAllUsers():Observable<any>{
    return this.http.get(this.api_url+"/api/User/AllUsers");
  }



  
}
