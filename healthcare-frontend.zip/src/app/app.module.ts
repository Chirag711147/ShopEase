import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppointmentComponent } from './components/appointment/appointment.component';
import { DoctorsComponent } from './components/doctors/doctors.component';
import { SigninComponent } from './components/signin/signin.component';
import { SignupComponent } from './components/signup/signup.component';
import { ProfileComponent } from './components/profile/profile.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { HeaderInterceptor } from './header.interceptor';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppointmentListingComponent } from './components/appointment-listing/appointment-listing.component';
import { AboutusComponent } from './components/aboutus/aboutus.component';
import { ServicesComponent } from './components/services/services.component';
import { NewsComponent } from './components/news/news.component';
import { DoctorAppointmentComponent } from './components/doctor-appointment/doctor-appointment.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    AppointmentComponent,
    DoctorsComponent,
    SigninComponent,
    SignupComponent,
    ProfileComponent,
    EditProfileComponent,
    AppointmentListingComponent,
    AboutusComponent,
    ServicesComponent,
    NewsComponent,
    DoctorAppointmentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
    
    
  ],
  providers: [
    {
      provide:HTTP_INTERCEPTORS, useClass: HeaderInterceptor, multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
